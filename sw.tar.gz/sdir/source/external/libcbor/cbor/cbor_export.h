/**
 * DO NOT DIRECTLY MODIFY THIS FILE:
 *
 * The code in this file is generated from scripts/import_libcbor.py
 * and any modifications should be in there.
 */

#ifndef CBOR_EXPORT_H
#define CBOR_EXPORT_H

/* Don't export anything from libcbor */
#define CBOR_EXPORT

#endif /* CBOR_EXPORT_H */
